const mongoose = require("mongoose");

const pageSchema = new mongoose.Schema(
  {
    chapter_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Chapter",
      required: true,
    },
    page_number: { type: Number, required: true },
    original_image_url: { type: String, default: "" },
    result_image_url: { type: String, default: "" },
    width: { type: Number, default: 0 },
    height: { type: Number, default: 0 },
    status: {
      type: String,
      enum: ["raw", "has_task", "submitted", "in_review", "approved", "revision"],
      default: "raw",
    },
    uploaded_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    current_version: { type: Number, default: 0 },
    is_locked: { type: Boolean, default: false },
    snapshots: {
      type: [
        {
          version: { type: Number, required: true },
          layers: { type: Array, default: [] },
          created_by: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
          created_at: { type: Date, default: Date.now },
          note: { type: String, default: "" },
        },
      ],
      default: [],
    },
  },
  { timestamps: true }
);

pageSchema.index({ chapter_id: 1, page_number: 1 });
pageSchema.index({ status: 1 });

const Page = mongoose.model("Page", pageSchema);
module.exports = Page;
